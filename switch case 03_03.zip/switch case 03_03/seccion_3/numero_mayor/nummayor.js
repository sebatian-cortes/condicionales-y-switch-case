let num1 = parseFloat(prompt("ingrese el primer numero"))
let num2 = parseFloat(prompt("ingrese el segundo numero"))

let menor = num1 < num2
let mayor = num1 > num2
let igual = num1 == num2

switch (menor || mayor || igual) {
    case menor:
        console.log("el primer numero es menor que el segundo")
        break;

    case mayor:
        console.log("el primer numero es mayor que el segundo")
        break;

    case igual:
        console.log("los dos numeros son iguales")    
        break;

    default:
        console.log("cifras no validas")
        break};