let edad = parseInt(prompt("ingrese su edad"))

let menor = edad < 18
let mayor = edad >= 18

switch (edad) {
    case menor:
        console.log("udted es menor de edad")
        break;

    case mayor:
        console.log("usted es mayor de edad")
        break;

    default:
        console.log("por favor ingrese una edad valida")
        break};