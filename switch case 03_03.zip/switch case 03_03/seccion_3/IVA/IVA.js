let producto = prompt("ingrese el producto que va llevar")

switch (producto) {
    case "crema":
        console.log("paga IVA")
        break;

    case "vino":
        console.log("paga IVA")
        break;
        
    case "lentejas":
        console.log("no paga IVA")
        break;

    case "arroz":
        console.log("no paga IVA")
        break;

    default:
        console.log("por favor ingrese un producto valido")
        break};