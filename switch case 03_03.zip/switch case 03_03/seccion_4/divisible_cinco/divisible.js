let num = parseInt(prompt("ingrese el numero que desea probar"))

let opcion1 = num % 5 == 0
let opcion2 = num % 5 < 0
let opcion3 = num % 5 > 0

switch (edad) {
    case opcion1:
        console.log("el numero si es divisible entre 5")

    case opcion2:
        console.log("el numero no es divisible entre 5")

    case opcion3:
        console.log("el numero no es divisible entre 5")    

    default:
        console.log("por favor ingrese un numero valido")
        break};