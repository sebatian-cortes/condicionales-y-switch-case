let año = parseInt(prompt("ingrese el año"))

if(año % 4 == 0 && año % 100 !==0){
    console.log("el año es bisisesto")
}else{
    console.log("el año no es bisiesto")
}