let longitud = parseFloat(prompt("ingrese la longitud numerica"))
let cambio = prompt("ingrese la unidad de medida a la que quiere cambiar la longitud")


switch (cambio){
    case "mm a cm":
        resultado = longitud / 10
        console.log("con el cambio de unidad el resultado es de:",resultado,"cm");
        break;

    case "mm a m":
        resultado = longitud / 1000
        console.log("con el cambio de unidad el resultado es de:",resultado,"m");
        break;
    
    case "mm a km":
        resultado = longitud / 100000
        console.log("con el cambio de unidad el resultado es de:",resultado,"km");
        break;
    

    case "cm a mm":
        resultado = longitud * 10
        console.log("con el cambio de unidad el resultado es de:",resultado,"m");
        break;

    case "cm a m":
        resultado = longitud / 10
        console.log("con el cambio de unidad el resultado es de:",resultado,"m");
        break;

    case "cm a km":
        resultado = longitud / 1000
        console.log("con el cambio de unidad el resultado es de:",resultado,"km");
        break;

    case "m a mm":
        resultado = longitud * 1000
        console.log("con el cambio de unidad el resultado es de:",resultado,"mm");
        break;

    case "m a cm":
        resultado = longitud * 10
        console.log("con el cambio de unidad el resultado es de:",resultado,"cm");
        break;

    case "m a km":
    resultado = longitud / 10
        console.log("con el cambio de unidad el resultado es de:" ,resultado,"km");
        break;

    case "km a mm":
        resultado = longitud * 100000
        console.log("con el cambio de unidad el resultado es de:",resultado,"mm");
        break;

    case "km a cm":
        resultado = longitud * 1000
        console.log("con el cambio de unidad el resultado es de:",resultado,"cm");
        break;

    case "km a m":
        resultado = longitud * 10
        console.log("con el cambio de unidad el resultado es de:",resultado,"m");
        break;


    default:
       
        break;
}