let frase = prompt("ingrese la frase")

if(frase.includes("ADSO") && frase.includes("desarrolladores")){
    console.log("la frase si contiene ADSO y desarrolladores")
}else{
    console.log("la frase no incluye ADSO o desarrolladores")
}